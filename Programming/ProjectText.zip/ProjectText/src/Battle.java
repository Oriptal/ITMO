import Team.Team;
import java.util.Random;

public record Battle(Team police, Team bandit) {
    public void start() {
        System.out.println("Началась перестрелка:\n");
        Random rand = new Random();
        int queue = rand.nextInt(2);
        while (police.isAlive() && bandit.isAlive()) {
            if (queue == 1) {
                police.moveAgainst(bandit);
            } else {
                bandit.moveAgainst(police);
            }
            police.decreaseEffects();
            bandit.decreaseEffects();
            queue ^= 1;
        }
    }
}
