import Team.Human.ImaginaryHuman.ImaginaryHumanType;
import Team.Team;

public class Main {
    public static void main(String... args) {
        Team police = new Team("Bebra", ImaginaryHumanType.POLICE);
        Team bandit = new Team("Goida", ImaginaryHumanType.BANDIT);
        Battle battle = new Battle(police, bandit);
        battle.start();
    }
}