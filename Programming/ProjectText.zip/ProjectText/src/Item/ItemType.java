package Item;

public enum ItemType {
    HEAL,
    WEAPON,
    CLOTHES
}
