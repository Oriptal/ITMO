package Item;

import Team.Human.ImaginaryHuman.ImaginaryHuman;

public interface IRepurchasing {
    default void purchase(ImaginaryHuman human, Item item) {
        if (item.getDurability() == 0) {
            try {
                item.setDurability(100);
                human.spendMoney(item.getCost());
                System.out.println("купив " + item);
            } catch (NotEnoughMoneyException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
