package Item.Weapon.Rifle.Shotgun;

public enum ShotgunType {
    M1014,
    Nova
}