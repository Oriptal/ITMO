package Team.Human.ImaginaryHuman;

import Item.Clothes.Clothes;
import Item.Item;
import Item.ItemType;
import Item.Medicines.Bandages;
import Item.Medicines.MedKit;
import Item.Medicines.Syringe;
import Item.Weapon.Weapon;
import Team.Human.Effect;
import Team.Human.Human;
import java.util.*;

abstract public class ImaginaryHuman extends Human {
    private double health;
    final public double agility;
    final public double humanAccuracy;
    final public double strength;
    final protected ArrayList<Item> inventory = new ArrayList<>();
    final protected HashMap<String, Clothes> clothes = new HashMap<>();
    final protected int[] effectTime = new int[4];
    protected final ImaginaryHumanType humanType;

    final protected class Hands extends Weapon {
        public Hands() {
            super(0.0, 0.0, 1, 2, -1, 0);
        }

        @Override
        public String toString() {
            return "Руки";
        }

        @Override
        protected double calculatePureDamage() {
            return ImaginaryHuman.this.strength;
        }
    }

    public ImaginaryHuman(String name, ImaginaryHumanType imaginaryHumanType) {
        super(name);
        Random rand = new Random();
        this.health = 100.0;
        double loadCapacity = rand.nextDouble(20) + 10;
        double maxInventoryVolume = rand.nextDouble(20) + 10;
        this.agility = rand.nextDouble(2);
        this.strength = rand.nextDouble(2);
        this.humanAccuracy = rand.nextDouble();
        if (rand.nextInt(3) < 1) {
            this.effectTime[1] = rand.nextInt(10);
        }
        this.humanType = imaginaryHumanType;
        this.addRifle();
        this.addHandWeapon();
        this.addClothes();
        this.addHeal();
        double sumWeight = 0;
        double sumVolume = 0;
        for (Item item : this.inventory) {
            sumWeight += item.getWeight();
            sumVolume += item.getVolume();
        }
        if (sumWeight > loadCapacity) {
            effectTime[2] = -1;
        }
        if (sumVolume > maxInventoryVolume) {
            effectTime[3] = -1;
        }

        System.out.println(this);
    }

    public double getHealth() {
        return health;
    }

    public void setClothes(String clothesName, Clothes clothesValue) {
        this.clothes.put(clothesName, clothesValue);
    }

    public double calcDamageWithClothes(double damage) {
        for (var item : this.clothes.values()) {
            damage = item.reduceDamage(this, damage);
        }
        return damage;
    }

    abstract protected void addRifle();
    abstract protected void addClothes();
    abstract protected void addHandWeapon();

    protected void addHeal() {
        Random rand = new Random();
        int healType = rand.nextInt(3);
        this.inventory.add(switch (healType) {
            case 0->(new Bandages());
            case 1->(new Syringe());
            case 2->(new MedKit());
            default -> throw new IllegalStateException("Unexpected value: " + healType);
        });
    }

    public void repairInventory() {
        for (Item item : this.inventory) {
            if (item.itemType == ItemType.WEAPON) {
                ((Weapon) item).repair();
            }
        }
    }

    public void changeHealth(double value) {
        double oldHealth = this.health;
        this.health += value;
        this.health = Math.max(0.0, Math.min(this.health, 100.0));
        if (this.health < oldHealth) {
            System.out.printf(this + "теряет %.2f очков здоровья.\n", (oldHealth - this.health));
        } else {
            System.out.printf(this + "восстанавливает %.2f очков здоровья.\n", (this.health - oldHealth));
        }
    }

    public boolean hasEffect(Effect e) {
        return effectTime[e.ordinal()] != 0;
    }

    public int getEffectTime(Effect e) {
        return effectTime[e.ordinal()];
    }

    public void addEffect(Effect e, int value) {
        this.effectTime[e.ordinal()] += value;
    }

    public boolean isAlive() {
        return (this.health > 0);
    }

    public Item chooseRandom(int itemType) {
        ArrayList<Item> items = new ArrayList<>();
        for (Item item : this.inventory) {
            if (item.itemType == ItemType.values()[itemType]) {
                items.add(item);
            }
        }
        int randomIndex = (new Random()).nextInt(items.size());
        return items.get(randomIndex);
    }

    public void attack(ImaginaryHuman opp, Weapon weapon) {
        weapon.dealDamage(this, opp);
        weapon.weaponPreparing(this);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        ImaginaryHuman that = (ImaginaryHuman) o;
        return Double.compare(health, that.health) == 0 && Double.compare(agility, that.agility) == 0 && Double.compare(humanAccuracy, that.humanAccuracy) == 0 && Double.compare(strength, that.strength) == 0 && Objects.equals(inventory, that.inventory) && Objects.equals(clothes, that.clothes) && Objects.deepEquals(effectTime, that.effectTime) && humanType == that.humanType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), health, agility, humanAccuracy, strength, inventory, clothes, Arrays.hashCode(effectTime), humanType);
    }

    public String description() {
        return (this.humanType == ImaginaryHumanType.POLICE ? "Полицейский ": "Бандит ") + getName();
    }

    @Override
    public String toString() {
        StringBuilder ans = new StringBuilder();
        if (this.agility > 1) {
            ans.append("Меткий ");
        }
        if (this.strength > 1) {
            ans.append("Сильный ");
        }
        for (int i = 0; i < this.effectTime.length; i++) {
            if (this.effectTime[i] != 0) {
                ans.append(Effect.values()[i].toString()).append("ный ");
            }
        }
        ans.append(this.humanType == ImaginaryHumanType.POLICE ? "Полицейский " : "Блатной ").append(super.getName()).append(".\n");
        if (!inventory.isEmpty()) ans.append("Он снаряжён:\n");
        else ans.append("У него ничего нет.");
        for (Item item : this.inventory) {
            if (item instanceof Hands) continue;
            ans.append(item).append(", ");
        }
        ans = new StringBuilder(ans.substring(0, ans.length() - 2));
        ans.append(".\n");
        ans.append("Он одет в ");
        for (var clothes : this.clothes.values()) {
            ans.append(clothes.toString()).append(", ");
        }
        ans = new StringBuilder(ans.substring(0, ans.length() - 2));
        ans.append(".\n");
        return ans.toString();
    }
}
