package Team.Human.ImaginaryHuman;

public enum ImaginaryHumanType {
    POLICE("полицейских"),
    BANDIT("блатных воров");

    private final String typeName;

    ImaginaryHumanType(String name) {
        this.typeName = name;
    }

    @Override
    public String toString() {
        return this.typeName;
    }
}
