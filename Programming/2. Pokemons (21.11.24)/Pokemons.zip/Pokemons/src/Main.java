import PokemonsClasses.*;
import ru.ifmo.se.pokemon.*;

class Main {
    public static void main(String[] args) {
        Battle b = new Battle();
        b.addAlly(new Trapinch("Willson", 1));
        b.addAlly(new Trapinch("Willow", 1));
        b.addFoe(new Vibrava("Wurt", 62));
        b.addAlly(new Darmanitan("Wolfgang", 44));
        b.addFoe(new Flygon("Maxwell", 68));
        b.addAlly(new Volcanion("Webber", 84));
        b.addAlly(new Volcanion("Wigfrid", 84));
        b.addAlly(new Darumaka("Charlie", 40));
        b.go();
    }
}